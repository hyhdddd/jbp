﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'ar', {
	alt: 'عنوان الصورة',
	btnUpload: 'أرسلها للخادم',
	captioned: 'Captioned image', // MISSING
	infoTab: 'معلومات الصورة',
	lockRatio: 'تناسق الحجم',
	menu: 'خصائص الصورة',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'إستعادة الحجم الأصلي',
	resizer: 'Click and drag to resize', // MISSING
	title: 'خصائص الصورة',
	uploadTab: 'رفع',
	urlMissing: 'عنوان مصدر الصورة مفقود'
} );
