﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'sk', {
	alt: 'Alternatívny text',
	btnUpload: 'Odoslať to na server',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informácie o obrázku',
	lockRatio: 'Pomer zámky',
	menu: 'Vlastnosti obrázka',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Pôvodná veľkosť',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Vlastnosti obrázka',
	uploadTab: 'Nahrať',
	urlMissing: 'Chýba URL zdroja obrázka.'
} );
